<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Activity\\Providers\\ActivityServiceProvider',
    1 => 'Modules\\Beehive\\Providers\\BeehiveServiceProvider',
    2 => 'Modules\\Category\\Providers\\CategoryServiceProvider',
    3 => 'Modules\\Guests\\Providers\\GuestsServiceProvider',
    4 => 'Modules\\OrderUser\\Providers\\OrderUserServiceProvider',
    5 => 'Modules\\Product\\Providers\\ProductServiceProvider',
    6 => 'Modules\\ProductCode\\Providers\\ProductCodeServiceProvider',
    7 => 'Modules\\ProductUser\\Providers\\ProductUserServiceProvider',
    8 => 'Modules\\Refferal\\Providers\\RefferalServiceProvider',
    9 => 'Modules\\Reward\\Providers\\RewardServiceProvider',
    10 => 'Modules\\SellerProduct\\Providers\\SellerProductServiceProvider',
    11 => 'Modules\\Sellers\\Providers\\SellersServiceProvider',
    12 => 'Modules\\Shared\\Providers\\SharedServiceProvider',
    13 => 'Modules\\TelephoneSeller\\Providers\\TelephoneSellerServiceProvider',
    14 => 'Modules\\User\\Providers\\UserServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Activity\\Providers\\ActivityServiceProvider',
    1 => 'Modules\\Beehive\\Providers\\BeehiveServiceProvider',
    2 => 'Modules\\Category\\Providers\\CategoryServiceProvider',
    3 => 'Modules\\Guests\\Providers\\GuestsServiceProvider',
    4 => 'Modules\\OrderUser\\Providers\\OrderUserServiceProvider',
    5 => 'Modules\\Product\\Providers\\ProductServiceProvider',
    6 => 'Modules\\ProductCode\\Providers\\ProductCodeServiceProvider',
    7 => 'Modules\\ProductUser\\Providers\\ProductUserServiceProvider',
    8 => 'Modules\\Refferal\\Providers\\RefferalServiceProvider',
    9 => 'Modules\\Reward\\Providers\\RewardServiceProvider',
    10 => 'Modules\\SellerProduct\\Providers\\SellerProductServiceProvider',
    11 => 'Modules\\Sellers\\Providers\\SellersServiceProvider',
    12 => 'Modules\\Shared\\Providers\\SharedServiceProvider',
    13 => 'Modules\\TelephoneSeller\\Providers\\TelephoneSellerServiceProvider',
    14 => 'Modules\\User\\Providers\\UserServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);