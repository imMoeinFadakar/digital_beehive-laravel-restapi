<?php

namespace Modules\Shared\Traits;


use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
trait UploadImageTrait {

     /**
     * آپلود تصویر به صورت عمومی و برگرداندن مسیر کامل URL
     *
     * @param UploadedFile $file
     * @param string $folder
     * @return string مسیر کامل قابل نمایش در مرورگر
     */
    public function uploadPublicImage(UploadedFile $file, string $folder = 'images'): string
    {
        // ساخت نام یکتا برای فایل
        $filename = Str::uuid() . '.' . $file->getClientOriginalExtension();

        // ذخیره در storage/app/public/images (یا هر فولدر داده شده)
        $path = $file->storeAs($folder, $filename, 'public');

        // تولید مسیر کامل URL
        return asset('storage/' . $path);
    }

}
