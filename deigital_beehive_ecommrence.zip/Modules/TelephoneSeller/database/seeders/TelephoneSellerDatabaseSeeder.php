<?php

namespace Modules\TelephoneSeller\Database\Seeders;

use Illuminate\Database\Seeder;

class TelephoneSellerDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
