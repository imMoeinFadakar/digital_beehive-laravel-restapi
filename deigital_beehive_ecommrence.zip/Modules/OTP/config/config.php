<?php

return [
    'name' => 'OTP',
];
