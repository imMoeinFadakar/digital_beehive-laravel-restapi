<?php

namespace Modules\OTP\Traits;


trait KavehnegarSmsTrait {



}
