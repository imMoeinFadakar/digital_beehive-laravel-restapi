<?php

namespace Modules\Reward\Database\Seeders;

use Illuminate\Database\Seeder;

class RewardDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
