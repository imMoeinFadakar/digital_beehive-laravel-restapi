<?php

return [
    'name' => 'SellerProduct',
];
