<x-sellerproduct::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('sellerproduct.name') !!}</p>
</x-sellerproduct::layouts.master>
