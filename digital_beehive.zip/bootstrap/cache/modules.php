<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Activity\\Providers\\ActivityServiceProvider',
    1 => 'Modules\\Auth\\Providers\\AuthServiceProvider',
    2 => 'Modules\\Beehive\\Providers\\BeehiveServiceProvider',
    3 => 'Modules\\Category\\Providers\\CategoryServiceProvider',
    4 => 'Modules\\OrderUser\\Providers\\OrderUserServiceProvider',
    5 => 'Modules\\Otp\\Providers\\OtpServiceProvider',
    6 => 'Modules\\Product\\Providers\\ProductServiceProvider',
    7 => 'Modules\\Refferal\\Providers\\RefferalServiceProvider',
    8 => 'Modules\\Reward\\Providers\\RewardServiceProvider',
    9 => 'Modules\\Sellers\\Providers\\SellersServiceProvider',
    10 => 'Modules\\Shared\\Providers\\SharedServiceProvider',
    11 => 'Modules\\TelephoneSeller\\Providers\\TelephoneSellerServiceProvider',
    12 => 'Modules\\User\\Providers\\UserServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Activity\\Providers\\ActivityServiceProvider',
    1 => 'Modules\\Auth\\Providers\\AuthServiceProvider',
    2 => 'Modules\\Beehive\\Providers\\BeehiveServiceProvider',
    3 => 'Modules\\Category\\Providers\\CategoryServiceProvider',
    4 => 'Modules\\OrderUser\\Providers\\OrderUserServiceProvider',
    5 => 'Modules\\Otp\\Providers\\OtpServiceProvider',
    6 => 'Modules\\Product\\Providers\\ProductServiceProvider',
    7 => 'Modules\\Refferal\\Providers\\RefferalServiceProvider',
    8 => 'Modules\\Reward\\Providers\\RewardServiceProvider',
    9 => 'Modules\\Sellers\\Providers\\SellersServiceProvider',
    10 => 'Modules\\Shared\\Providers\\SharedServiceProvider',
    11 => 'Modules\\TelephoneSeller\\Providers\\TelephoneSellerServiceProvider',
    12 => 'Modules\\User\\Providers\\UserServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);