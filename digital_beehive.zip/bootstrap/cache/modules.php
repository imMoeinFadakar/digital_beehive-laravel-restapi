<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Activity\\Providers\\ActivityServiceProvider',
    1 => 'Modules\\Auth\\Providers\\AuthServiceProvider',
    2 => 'Modules\\Beehive\\Providers\\BeehiveServiceProvider',
    3 => 'Modules\\Category\\Providers\\CategoryServiceProvider',
    4 => 'Modules\\OrderUser\\Providers\\OrderUserServiceProvider',
    5 => 'Modules\\OrderUserStatus\\Providers\\OrderUserStatusServiceProvider',
    6 => 'Modules\\Otp\\Providers\\OtpServiceProvider',
    7 => 'Modules\\Product\\Providers\\ProductServiceProvider',
    8 => 'Modules\\Refferal\\Providers\\RefferalServiceProvider',
    9 => 'Modules\\Reward\\Providers\\RewardServiceProvider',
    10 => 'Modules\\Sellers\\Providers\\SellersServiceProvider',
    11 => 'Modules\\Shared\\Providers\\SharedServiceProvider',
    12 => 'Modules\\TelephoneSeller\\Providers\\TelephoneSellerServiceProvider',
    13 => 'Modules\\User\\Providers\\UserServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Activity\\Providers\\ActivityServiceProvider',
    1 => 'Modules\\Auth\\Providers\\AuthServiceProvider',
    2 => 'Modules\\Beehive\\Providers\\BeehiveServiceProvider',
    3 => 'Modules\\Category\\Providers\\CategoryServiceProvider',
    4 => 'Modules\\OrderUser\\Providers\\OrderUserServiceProvider',
    5 => 'Modules\\OrderUserStatus\\Providers\\OrderUserStatusServiceProvider',
    6 => 'Modules\\Otp\\Providers\\OtpServiceProvider',
    7 => 'Modules\\Product\\Providers\\ProductServiceProvider',
    8 => 'Modules\\Refferal\\Providers\\RefferalServiceProvider',
    9 => 'Modules\\Reward\\Providers\\RewardServiceProvider',
    10 => 'Modules\\Sellers\\Providers\\SellersServiceProvider',
    11 => 'Modules\\Shared\\Providers\\SharedServiceProvider',
    12 => 'Modules\\TelephoneSeller\\Providers\\TelephoneSellerServiceProvider',
    13 => 'Modules\\User\\Providers\\UserServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);