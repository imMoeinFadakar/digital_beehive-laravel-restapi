<?php

return [
    'name' => 'ProductUser',
];
