<x-productuser::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('productuser.name') !!}</p>
</x-productuser::layouts.master>
