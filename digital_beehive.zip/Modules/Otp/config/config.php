<?php

return [
    'name' => 'Otp',
];
