<x-otp::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('otp.name') !!}</p>
</x-otp::layouts.master>
