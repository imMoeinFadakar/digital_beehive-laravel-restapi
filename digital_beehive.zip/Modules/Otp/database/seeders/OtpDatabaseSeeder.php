<?php

namespace Modules\Otp\Database\Seeders;

use Illuminate\Database\Seeder;

class OtpDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
