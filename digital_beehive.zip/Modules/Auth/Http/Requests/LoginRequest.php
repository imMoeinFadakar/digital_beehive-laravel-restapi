<?php

namespace Modules\Auth\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class LoginRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            "phone_number" => "required|email|exists:users,phone_number",
            "password" => "required|min:8" 
        ];
    }

    public function messages()
    {
        return [
            'phone_number.required' => 'وارد کردن شماره الزامی است.',
            'phone_number.exists' => 'کاربری با این شماره یافت نشد.',
            'password.required' => 'رمز عبور الزامی است.',
            'password.min' => 'رمز عبور باید حداقل ۸ کاراکتر باشد.',
        ];
    }


    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }
}
