<x-orderuserstatus::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('orderuserstatus.name') !!}</p>
</x-orderuserstatus::layouts.master>
