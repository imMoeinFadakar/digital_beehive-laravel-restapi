<x-beehive::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('beehive.name') !!}</p>
</x-beehive::layouts.master>
