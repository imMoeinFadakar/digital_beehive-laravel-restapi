<x-activity::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('activity.name') !!}</p>
</x-activity::layouts.master>
