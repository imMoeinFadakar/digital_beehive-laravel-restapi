<?php

return [
    'name' => 'Reward',
];
