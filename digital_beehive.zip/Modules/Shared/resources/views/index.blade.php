<x-shared::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('shared.name') !!}</p>
</x-shared::layouts.master>
