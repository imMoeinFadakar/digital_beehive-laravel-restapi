<?php

return [
    'name' => 'Refferal',
];
