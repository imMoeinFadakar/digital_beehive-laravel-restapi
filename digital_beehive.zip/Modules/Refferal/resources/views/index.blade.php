<x-refferal::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('refferal.name') !!}</p>
</x-refferal::layouts.master>
