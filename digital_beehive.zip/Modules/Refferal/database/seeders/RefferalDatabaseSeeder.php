<?php

namespace Modules\Refferal\Database\Seeders;

use Illuminate\Database\Seeder;

class RefferalDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
