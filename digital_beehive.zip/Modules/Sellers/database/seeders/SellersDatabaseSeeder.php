<?php

namespace Modules\Sellers\Database\Seeders;

use Illuminate\Database\Seeder;

class SellersDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
