<x-sellers::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('sellers.name') !!}</p>
</x-sellers::layouts.master>
