<?php

return [
    'name' => 'Sellers',
];
