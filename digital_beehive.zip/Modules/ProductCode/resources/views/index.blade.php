<x-productcode::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('productcode.name') !!}</p>
</x-productcode::layouts.master>
