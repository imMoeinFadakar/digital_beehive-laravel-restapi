<?php

namespace Modules\ProductCode\Database\Seeders;

use Illuminate\Database\Seeder;

class ProductCodeDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
