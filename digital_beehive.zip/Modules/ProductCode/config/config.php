<?php

return [
    'name' => 'ProductCode',
];
