<?php

return [
    'name' => 'TelephoneSeller',
];
