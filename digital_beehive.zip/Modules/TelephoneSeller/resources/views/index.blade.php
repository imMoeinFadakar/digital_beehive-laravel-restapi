<x-telephoneseller::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('telephoneseller.name') !!}</p>
</x-telephoneseller::layouts.master>
