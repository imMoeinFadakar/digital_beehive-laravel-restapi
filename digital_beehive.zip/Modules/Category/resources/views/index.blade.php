<x-category::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('category.name') !!}</p>
</x-category::layouts.master>
