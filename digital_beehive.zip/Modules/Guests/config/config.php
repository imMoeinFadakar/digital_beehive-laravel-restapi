<?php

return [
    'name' => 'Guests',
];
