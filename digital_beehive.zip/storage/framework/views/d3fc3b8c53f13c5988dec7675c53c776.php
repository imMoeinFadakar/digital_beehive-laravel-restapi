<img src="https://app.honeykoohpayeh.ir/12.png" width="50" alt="لگو">


<?php /**PATH D:\Copy\koohpaie_IT\digital_beehive\resources\views/components/application-logo.blade.php ENDPATH**/ ?>