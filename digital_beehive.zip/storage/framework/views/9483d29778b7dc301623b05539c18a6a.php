<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('مشاهده لیست خرید های کاربر')); ?>

        </h2>
     <?php $__env->endSlot(); ?>




    <div class="container mt-5">
    <h2 class="mb-4">جدول سفارشات کاربر</h2>

        <?php if(! $orders & $orders === []): ?>

            <h2>محصولی یافت نشد</h2>

        <?php else: ?>

               <table class="table table-bordered table-striped table-hover">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>نام محصول</th>
                <th>تعداد</th>
                <th>قیمت کل</th>
                <th> وضعیت سفارش</th>

            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            <tr>
                <td><?php echo e($order->id); ?></td>
                <td><?php echo e($order->product->name); ?></td>
                <td><?php echo e($order->quentity); ?></td>
                <td><?php echo e($order->quentity * $order->product->price); ?></td>
                <td><?php echo e($order->status == "in_proccess" ? "در انتظار تایید سفارش" : "کامل شده"); ?></td>
                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
            <!-- ردیف‌های بیشتر -->
        </tbody>
    </table>

        <?php endif; ?>

 
</div>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\Copy\koohpaie_IT\digital_beehive\resources\views/ProductUserView.blade.php ENDPATH**/ ?>