<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('پنل فروشندگان')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    
                    <p  clas >کد دعوت شما:
                        <button class="btn btn-dark" onclick="copyToClipboard()">📋 کپی کن</button>
                        <a id="inviteLink" href="<?php echo e($sellerRefferalCode); ?>" target="_blank">
                           <?php echo e($sellerRefferalCode); ?>

                        </a>
                    </p>
              
                </div>
            </div>
        </div>
    </div>





    <div class="container mt-5">

    <table class="table table-bordered table-striped table-hover">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>نام</th>
                <th>نام خانوادگی</th>
                <th>ایمیل</th>
                <th>شماره تماس</th>
                <th> وضعیت سفارشات کاربر</th>
                <th>دیدن زیرمجموعه کاربر</th>
                <th>رفرال های کاربر</th>
                <th> ثبت گزارش </th>



            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $sellerUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            <tr>
                <td><?php echo e($index +1); ?></td>
                <td><?php echo e($user->user->first_name); ?></td>
                <td><?php echo e($user->user->last_name); ?></td>
                <td><?php echo e($user->user->email); ?></td>
                <td><?php echo e($user->user->phone_number); ?></td>
                <td>
                    <a  class="btn btn-success" href="<?php echo e(route("user.product.get",$user->user->id)); ?>">وضعیت خریدها</a>
                </td>
                 <td>
                    <a  class="btn btn-danger" href="<?php echo e(route("reffrals",[$user->user->refferal_code, $gen + 1 ])); ?>">مشاهده</a>
                </td>
                <td><?php echo e($user->referrals_count); ?></td>
                <td>
                    <a  class="btn btn-warning" href="<?php echo e(route("new.report.create",$user->user->refferal_code)); ?>">ثبت گزارش</a>
                </td>

            </tr>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- ردیف‌های بیشتر -->
        </tbody>
    </table>
</div>
<div class="d-flex justify-content-center">
    <?php echo e($sellerUser->links()); ?>

</div>
<script>
    function copyToClipboard() {
        const link = document.getElementById("inviteLink").href;

        // کپی کردن به کلیپ‌بورد
        navigator.clipboard.writeText(link).then(function() {
            alert("لینک با موفقیت کپی شد!");
        }, function(err) {
            alert("خطا در کپی کردن لینک: " + err);
        });
    }
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Copy\koohpaie_IT\digital_beehive\resources\views/dashboard.blade.php ENDPATH**/ ?>