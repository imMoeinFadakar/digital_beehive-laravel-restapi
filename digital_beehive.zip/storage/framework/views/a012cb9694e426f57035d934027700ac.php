<head>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('پنل فروشندگان')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6 sm:py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <!-- کد دعوت -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg p-6">
                <p class="flex flex-col sm:flex-row items-start sm:items-center gap-2">
                    <span>کد دعوت شما:</span>
                    <div class="flex items-center gap-2">
                        <button class="bg-gray-800 text-white px-3 py-1 rounded hover:bg-gray-700 text-sm" onclick="copyToClipboard()">کپی</button>
                        <a id="inviteLink" href="<?php echo e($sellerRefferalCode); ?>" target="_blank" class="text-blue-600 break-all">
                            <?php echo e($sellerRefferalCode); ?>

                        </a>
                    </div>
                </p>
            </div>

            <!-- جدول دسکتاپ -->
            <div class="hidden md:block bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg p-4">
                <div class="overflow-x-auto">
                    <table class="min-w-max w-full text-sm text-left border-collapse table-auto">
                        <thead class="bg-gray-800 text-white">
                            <tr>
                                <th class="px-4 py-2 whitespace-nowrap">#</th>
                                <th class="px-4 py-2 whitespace-nowrap">نام</th>
                                <th class="px-4 py-2 whitespace-nowrap">نام خانوادگی</th>
                                <th class="px-4 py-2 whitespace-nowrap">ایمیل</th>
                                <th class="px-4 py-2 whitespace-nowrap">شماره تماس</th>
                                <th class="px-4 py-2 whitespace-nowrap">وضعیت سفارشات</th>
                                <th class="px-4 py-2 whitespace-nowrap">زیرمجموعه‌ها</th>
                                <th class="px-4 py-2 whitespace-nowrap">تعداد رفرال</th>
                                <th class="px-4 py-2 whitespace-nowrap">گزارش</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sellerUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="border-b border-gray-200 dark:border-gray-700">
                                    <td class="px-4 py-2 whitespace-nowrap"><?php echo e($index + 1); ?></td>
                                    <td class="px-4 py-2 whitespace-nowrap"><?php echo e($user->user->first_name); ?></td>
                                    <td class="px-4 py-2 whitespace-nowrap"><?php echo e($user->user->last_name); ?></td>
                                    <td class="px-4 py-2 break-all"><?php echo e($user->user->email); ?></td>
                                    <td class="px-4 py-2 whitespace-nowrap"><?php echo e($user->user->phone_number); ?></td>
                                    <td class="px-4 py-2 whitespace-nowrap">
                                        <a class="bg-green-600 text-white px-2 py-1 rounded hover:bg-green-700 text-xs" href="<?php echo e(route('user.product.get', $user->user->id)); ?>">خریدها</a>
                                    </td>
                                    <td class="px-4 py-2 whitespace-nowrap">
                                        <a class="bg-red-600 text-white px-2 py-1 rounded hover:bg-red-700 text-xs" href="<?php echo e(route('reffrals', [$user->user->refferal_code, $gen + 1])); ?>">مشاهده</a>
                                    </td>
                                    <td class="px-4 py-2 whitespace-nowrap"><?php echo e($user->referrals_count); ?></td>
                                    <td class="px-4 py-2 whitespace-nowrap">
                                        <a class="bg-yellow-500 text-white px-2 py-1 rounded hover:bg-yellow-600 text-xs" href="<?php echo e(route('new.report.create', $user->user->refferal_code)); ?>">ثبت گزارش</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <!-- صفحه‌بندی دسکتاپ -->
                <div class="mt-4">
                    <?php echo e($sellerUser->links()); ?>

                </div>
            </div>

            <!-- کارت موبایل -->
           <!-- کارت موبایل -->
<div class="md:hidden space-y-4">
    <?php $__currentLoopData = $sellerUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-white dark:bg-gray-800 shadow-sm rounded-lg p-4 space-y-2">
            <div class="flex justify-between">
                <span class="font-semibold">شماره</span>
                <span><?php echo e($index + 1); ?></span>
            </div>
            <div class="flex justify-between">
                <span class="font-semibold">نام</span>
                <span><?php echo e($user->user->first_name); ?></span>
            </div>
            <div class="flex justify-between">
                <span class="font-semibold">نام خانوادگی</span>
                <span><?php echo e($user->user->last_name); ?></span>
            </div>
            <div class="flex justify-between">
                <span class="font-semibold">ایمیل</span>
                <span class="break-all"><?php echo e($user->user->email); ?></span>
            </div>
            <div class="flex justify-between">
                <span class="font-semibold">شماره تماس</span>
                <span><?php echo e($user->user->phone_number); ?></span>
            </div>
               <div class="flex justify-between mt-2">
                <span class="font-semibold">تعداد رفرال</span>
                <span><?php echo e($user->referrals_count); ?></span>
            </div>
            <div class="flex flex-col sm:flex-row gap-3 mt-2">
                <a class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 text-sm text-center" href="<?php echo e(route('user.product.get', $user->user->id)); ?>">خرید های کاربر</a>
                <a class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 text-sm text-center" href="<?php echo e(route('reffrals', [$user->user->refferal_code, $gen + 1])); ?>">مشاهده زیر مجموعه ها</a>
                <a class="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600 text-sm text-center" href="<?php echo e(route('new.report.create', $user->user->refferal_code)); ?>">ثبت گزارش</a>
            </div>
         
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- صفحه‌بندی موبایل -->
    <div class="mt-4">
        <?php echo e($sellerUser->links()); ?>

    </div>
</div>


        </div>
    </div>

    <script>
        function copyToClipboard() {
            const link = document.getElementById("inviteLink").href;
            navigator.clipboard.writeText(link).then(() => {
                alert("لینک با موفقیت کپی شد!");
            }).catch(err => {
                alert("خطا در کپی کردن لینک: " + err);
            });
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Copy\koohpaie_IT\digital_beehive\resources\views/dashboard.blade.php ENDPATH**/ ?>