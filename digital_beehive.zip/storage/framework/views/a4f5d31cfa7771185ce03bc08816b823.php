<?php echo e($slot); ?>

<?php /**PATH D:\Copy\koohpaie_IT\digital_beehive\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>