<head>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('لیست سفارشات')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <!-- پیام موفقیت -->
            <?php if(session('success')): ?>
                <div class="mb-4 p-4 bg-green-100 text-green-800 rounded-lg">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <!-- پیام خطا -->
            <?php if(session('error')): ?>
                <div class="mb-4 p-4 bg-red-100 text-red-800 rounded-lg">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <!-- جدول دسکتاپ -->
            <div class="hidden md:block overflow-x-auto bg-white dark:bg-gray-800 shadow-md rounded-lg">
                <table class="min-w-full text-sm text-center divide-y divide-gray-200 dark:divide-gray-700">
                    <thead class="bg-gray-800 text-white">
                        <tr>
                            <th class="px-4 py-3">ردیف</th>
                            <th class="px-4 py-3">نام</th>
                            <th class="px-4 py-3">نام خانوادگی</th>
                            <th class="px-4 py-3">شماره همراه</th>
                            <th class="px-4 py-3">کد پستی</th>
                            <th class="px-4 py-3">تعداد</th>
                            <th class="px-4 py-3">نام محصول</th>
                            <th class="px-4 py-3">قیمت تکی</th>
                            <th class="px-4 py-3">قیمت کل</th>
                            <th class="px-4 py-3">نوع پرداخت</th>
                            <th class="px-4 py-3">شناسه پیگیری</th>
                            <th class="px-4 py-3">وضعیت سفارش</th>
                            <th class="px-4 py-3">تأیید سفارش</th>
                            <th class="px-4 py-3">مشاهده بالاسری‌ها</th>
                            <th class="px-4 py-3">دیدن فروشنده</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-4 py-2"><?php echo e($order->id); ?></td>
                                <td class="px-4 py-2"><?php echo e($order->user->first_name); ?></td>
                                <td class="px-4 py-2"><?php echo e($order->user->last_name); ?></td>
                                <td class="px-4 py-2"><?php echo e($order->user->phone_number); ?></td>
                                <td class="px-4 py-2"><?php echo e($order->user->postal_code); ?></td>
                                <td class="px-4 py-2"><?php echo e($order->quentity); ?></td>
                                <td class="px-4 py-2"><?php echo e($order->product->name); ?></td>
                                <td class="px-4 py-2"><?php echo e(number_format($order->product->price)); ?> تومان</td>
                                <td class="px-4 py-2"><?php echo e(number_format($order->product->price * $order->quentity)); ?> تومان</td>
                                <td class="px-4 py-2">
                                    <?php if($order->payment_method == "card_to_card"): ?>
                                        کارت به کارت
                                    <?php elseif($order->payment_method == "pay_at_home"): ?>
                                        درب منزل
                                    <?php else: ?>
                                        درگاه پرداخت
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-2">
                                    <?php if($order->transaction_number == "pay_at_home"): ?>
                                        درب منزل
                                    <?php else: ?>
                                        <?php echo e($order->transaction_number); ?>

                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-2">
                                    <?php echo e($order->status == 'in_proccess' ? 'در انتظار تایید' : 'تایید شده'); ?>

                                </td>
                                <td class="px-4 py-2">
                                    <a href="<?php echo e(route('confirm', [$order->user_id, $order->id])); ?>"
                                       class="inline-block bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700 transition">
                                        تأیید
                                    </a>
                                </td>
                                <td class="px-4 py-2">
                                    <a href="<?php echo e(route('parent', $order->user_id)); ?>"
                                       class="inline-block bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700 transition">
                                        مشاهده
                                    </a>
                                </td>
                                <td class="px-4 py-2">
                                    <a href="<?php echo e(route('seller.user', $order->user_id)); ?>"
                                       class="inline-block bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700 transition">
                                        فروشنده
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- کارت موبایل -->
            <div class="md:hidden space-y-4">
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white dark:bg-gray-800 shadow rounded-lg p-4 space-y-2">
                        <div class="flex justify-between"><span class="font-semibold">ردیف</span><span><?php echo e($order->id); ?></span></div>
                        <div class="flex justify-between"><span class="font-semibold">نام</span><span><?php echo e($order->user->first_name); ?></span></div>
                        <div class="flex justify-between"><span class="font-semibold">نام خانوادگی</span><span><?php echo e($order->user->last_name); ?></span></div>
                        <div class="flex justify-between"><span class="font-semibold">شماره همراه</span><span><?php echo e($order->user->phone_number); ?></span></div>
                        <div class="flex justify-between"><span class="font-semibold">کد پستی</span><span><?php echo e($order->user->postal_code); ?></span></div>
                        <div class="flex justify-between"><span class="font-semibold">تعداد</span><span><?php echo e($order->quentity); ?></span></div>
                        <div class="flex justify-between"><span class="font-semibold">محصول</span><span><?php echo e($order->product->name); ?></span></div>
                        <div class="flex justify-between"><span class="font-semibold">قیمت تکی</span><span><?php echo e(number_format($order->product->price)); ?> تومان</span></div>
                        <div class="flex justify-between"><span class="font-semibold">قیمت کل</span><span><?php echo e(number_format($order->product->price * $order->quentity)); ?> تومان</span></div>
                        <div class="flex justify-between"><span class="font-semibold">نوع پرداخت</span><span>
                            <?php if($order->payment_method == "card_to_card"): ?>
                                کارت به کارت
                            <?php elseif($order->payment_method == "pay_at_home"): ?>
                                درب منزل
                            <?php else: ?>
                                درگاه پرداخت
                            <?php endif; ?>
                        </span></div>
                        <div class="flex justify-between"><span class="font-semibold">شناسه پیگیری</span><span>
                            <?php if($order->transaction_number == "pay_at_home"): ?>
                                درب منزل
                            <?php else: ?>
                                <?php echo e($order->transaction_number); ?>

                            <?php endif; ?>
                        </span></div>
                        <div class="flex justify-between"><span class="font-semibold">وضعیت سفارش</span>
                            <span class="px-3 py-1 rounded <?php echo e($order->status == 'in_proccess' ? 'bg-red-400 text-white' : 'bg-green-400 text-white'); ?>">
                                <?php echo e($order->status == 'in_proccess' ? 'در انتظار تایید' : 'تایید شده'); ?>

                            </span>
                        </div>
                        <div class="flex flex-col sm:flex-row gap-2 mt-4">
                            <a href="<?php echo e(route('confirm', [$order->user_id, $order->id])); ?>"
                               class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 text-center transition">
                                تایید سفارش کاربر
                            </a>
                            <a href="<?php echo e(route('parent', $order->user_id)); ?>"
                               class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 text-center transition">
                                مشاهده بالاسری ها
                            </a>
                            <a href="<?php echo e(route('seller.user', $order->user_id)); ?>"
                               class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 text-center transition">
                                مشاهده اطلاعات فروشنده
                            </a>
                            
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Copy\koohpaie_IT\digital_beehive\resources\views/OrderUser.blade.php ENDPATH**/ ?>