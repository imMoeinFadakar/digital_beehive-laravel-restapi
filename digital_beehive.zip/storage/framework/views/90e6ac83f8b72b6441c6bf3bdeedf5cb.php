<!DOCTYPE html>
<html lang="fa">
<head>
  <meta charset="UTF-8">
  <title>جدول 10 ستونه</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">

    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>




  <div class="container">
    <h4 class="mb-4">لیست سفارشات</h4>

    <table class="table table-bordered text-center">
      <thead class="table-primary">
        <tr>
          <th>ردیف</th>
          <th>نام </th>
          <th> نام خانوادگی</th>
          <th> شماره همراه</th>
          <th>کد پستی</th>
          <th> تعداد</th>
          <th>نام محصول</th>
          <th>قیمت تکی محصول</th>
          <th> قیمت کل فاکتور</th>
          <th>وضعیت سفارش</th>
          <th>تأیید سفارش</th>
          <th> مشاهده بالاسری ها</th>

        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
          <td><?php echo e($order->id); ?></td>
          <td><?php echo e($order->user->first_name); ?></td>
          <td><?php echo e($order->user->last_name); ?></td>
          <td><?php echo e($order->user->phone_number); ?></td>
          <td><?php echo e($order->user->postal_code); ?></td>
          <td><?php echo e($order->quentity); ?></td>
          <td><?php echo e($order->product->name); ?></td>
          <td><?php echo e($order->product->price); ?></td>
          <td><?php echo e($order->product->price * $order->quentity); ?></td>
          <td><?php echo e($order->status == "in_proccess" ? "در انتظار تایید" : "تایید"); ?> </td>
          <td>
            <a href="<?php echo e(route("confirm",[$order->user_id,$order->id])); ?>" class="btn btn-success btn-sm">تأیید سفارش</a>
          </td>
            <td>
            <a href="<?php echo e(route("parent",$order->user_id)); ?>" class="btn btn-success btn-sm"> مشاهده بالاسری ها</a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
        <!-- ردیف‌های بیشتر را می‌توان داینامیک اضافه کرد -->
      </tbody>
    </table>
  </div>

</body>
</html>
<?php /**PATH D:\Copy\koohpaie_IT\digital_beehive\resources\views/OrderUser.blade.php ENDPATH**/ ?>